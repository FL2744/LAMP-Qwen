# LAMP-Qwen: Forward-Only Associative Memory for a Frozen Small Language Model

William Taggart  
Modern and Classical Languages and Literatures, Virginia Tech  
wtaggart@vt.edu

Report date: November 13, 2026

## Abstract

LAMP-Qwen extends Latent Associative Memory Programming (LAMP) from a small, one-word question–answer model to Qwen3.5-0.8B. A frozen pretrained transformer is augmented with editable numerical memory at the entrance to its final feed-forward network. A forward-only writer stores a normalized recognition key and differences between source and donor hidden states. A single stored adjustment changed responses but did not reproduce either of two initial target answers exactly. A sequence extension instead stores one adjustment per decoding step and reproduced all 12 selected target answers in a development pilot. Replacement, persistence, and clearing were also demonstrated; five unrelated questions retained their baseline answers, and hashes of the base model’s parameters were unchanged. These results establish a narrow implementation result: selected answers can be programmed through additional activation-steering tensors without gradient updates to the base model. They do not establish general semantic memory, reliable paraphrase recognition, or performance across the full 1,000-question catalogue. This report describes the intervention, writer, computational costs, practical uses, and limits of the evidence, including a subsequent candidate-based recovery of a programmed association from an exported memory.

## Purpose and scope

A pretrained language model contains knowledge distributed across many parameters, but those parameters are difficult for a user to edit directly. LAMP explores a more accessible interface: a separate numerical memory whose entries recognize a question state and redirect the computation that produces its answer. The original educational implementation uses a 77,568-parameter transformer with width 64 and 16 memory slots, containing 2,048 memory values in total [1](#ref-lamp). Its task is restricted to one-word answers.

LAMP-Qwen preserves the central design—a frozen base, an initially inactive memory, and an explicit writer—while moving to a pretrained model that generates multiple tokens. The intended use is deliberate programming of selected question–answer associations. Memory is not automatically written on every forward pass. A user supplies a source question and a desired answer, then invokes the writer.

The distinction between *training* and *writing* is essential. Qwen has already undergone substantial training. The present writer uses model inference, tensor subtraction, normalization, and validation; it does not perform backpropagation or optimizer steps. The resulting memory supplements the base model rather than replacing its pretrained parameters.

This prototype also distinguishes numerical storage from a conventional response lookup. During ordinary inference, the runtime does not retrieve a stored answer string and print it. It selects numerical adjustments and continues the model’s forward computation. Nevertheless, the sequence extension explicitly depends on decoding position and stores a trajectory for a particular answer. Its behavior should therefore be understood as restricted activation replay, not as proof that a compact, general-purpose semantic memory has been learned.

![Intervention at the final feed-forward stage](figures/illustration-01.png)

*Illustration 1. Two-branch intervention schematic. The same displacement enters the normalization input and the residual path; no later attention layer follows this insertion point.*

## Model and intervention point

The implementation loads the official `Qwen/Qwen3.5-0.8B` checkpoint at a fixed revision:\
`2fc06364715b967f1860aea9cf38778875588b17`. Its text decoder has 24 layers, hidden width $d=1024$, feed-forward intermediate width 3,584, and an output vocabulary dimension of 248,320 [2](#ref-qwen). Its hybrid stack alternates groups of linear-attention layers with full-attention layers; the final decoder layer uses full attention.

Experiments use the text path of the conditional-generation model, float32 weights, eager attention, evaluation mode, and disabled parameter gradients. Generation is greedy, uses a cache, and disables the thinking mode through the chat template. The source prompt asks for a direct, concise answer in one or two sentences. Tests ran on an M4 Mac mini with 16 GB unified memory using PyTorch’s Metal backend. The recorded environment uses Python 3.14, PyTorch 2.15.0, and Transformers 5.22.2.

Although an Ollama installation motivated the project, this implementation runs through Transformers. The ordinary Ollama chat API does not provide the internal layer hooks used here [3](#ref-ollama). The existing quantized Ollama model is left unchanged; its results and resource requirements should not be conflated with those of this float32 implementation.

### Changing both the feed-forward input and its residual

Let $h_t\in\mathbb{R}^{1024}$ be the final decoder layer’s state after the attention residual at decoding step $t$. Without memory, the remaining block computes
$$

u_t=h_t+\operatorname{FFN}\!\left(\operatorname{RMSNorm}(h_t)\right).

$$
Memory supplies an adjustment $\delta_t$, producing
$$

u'_t=(h_t+\delta_t)+
\operatorname{FFN}\!\left(\operatorname{RMSNorm}(h_t+\delta_t)\right).

$$
The final model normalization and output head then produce vocabulary logits.

A pre-hook on the layer’s post-attention normalization adds $\delta_t$ to its input. A second hook adds the same adjustment to the layer output, accounting for the residual path. Modifying the normalization input alone would not implement Equation (2). During prompt processing only the final token state is edited. Cached generation then processes the newly generated position. No subsequent attention layer consumes the edited state.

Question tokens → pretrained decoder → $h_t$; then $h_t+\delta_t$ → final FFN and residual → final normalization → vocabulary logits.

### Recognition and routing

The memory has $S=1000$ slots. It stores a key matrix $K\in\mathbb{R}^{S\times d}$ and an adjustment matrix $D\in\mathbb{R}^{S\times d}$, initially zero. Each slot also has an enabled flag, a threshold, and a gain. For a source state $h_0$, writing sets
$$

K_i=\frac{h_0}{\lVert h_0\rVert_2},
\qquad
s_i=\left\langle\frac{\widetilde h_0}{\lVert\widetilde h_0\rVert_2},K_i\right\rangle .

$$
At inference, $\widetilde h_0$ is the current question state. The highest-scoring enabled slot at or above its threshold is selected, with a default threshold of 0.999. With unit keys, scores are cosine similarities, not probabilities. Direct key edits can break the unit-length assumption. Selection is made once and held for the answer. If no slot qualifies, the original computation is retained.

![Authoring and validating an answer trajectory](figures/illustration-02.png)

*Illustration 2. Sequence writer. Source and donor traces are teacher-forced with matching prefixes; a failed free-generation validation restores the prior memory.*

## The forward-only writer

### Single-adjustment mode

The original LAMP mechanism stores a source-to-donor displacement. A donor state $h^\ast_0$ is obtained from a prompt that leads toward the desired answer. The writer records
$$

K_i=h_0/\lVert h_0\rVert_2,\qquad D_i=h^\ast_0-h_0.

$$
For the exact source state and unit gain, $h_0+D_i=h^\ast_0$: the remaining feed-forward network and output head receive the donor’s state. This identity applies to that position. It does not imply that the same adjustment will remain correct after new answer tokens are generated.

Single mode applies the same adjustment at every decoding step. In the initial two-question smoke test, it changed the generated responses but neither complete response matched its target. This motivated the sequence writer. The donor prompts also evolved during development, so these observations are not a controlled comparison isolating the effect of sequence memory.

### Sequence-adjustment mode

The default writer constructs a sequence $\Delta_i=(\delta_{i,0},\ldots,\delta_{i,L-1})$:

1.  **Generate a donor answer.** A separate prompt instructs the model to copy the desired answer verbatim, including all sentences and punctuation. The writer rejects unfinished generations or outputs that do not match the target after case and whitespace normalization.

2.  **Align the two trajectories.** Let $y_0,\ldots,y_{L-1}$ be the donor’s generated token sequence, including the stop token. Run the source-question prompt and donor-copy prompt with the same generated prefixes, using teacher forcing. Capture the pre-FFN state at each answer-prediction position.

3.  **Calculate the adjustments.** For each position, store
    $$
    
    \delta_{i,t}=h^\ast_t-h_t,\qquad t=0,\ldots,L-1.
    
    $$
    The recognition key uses the source state before the first answer token. The writer also checks that the teacher-forced donor argmax tokens reproduce the donor generation.

4.  **Validate and commit.** Generate freely from the source question with the proposed memory. Save the entry only if the complete answer passes the same normalized-text comparison. Otherwise restore the previous memory.

At inference, the selected slot supplies the adjustment for the current decoding position, multiplied by its gain. After the stored trajectory ends, it supplies no further adjustment. The construction assumes the source question, prompting, model, and generation settings match those used when writing.

For an exact source and matching prefix, the source state plus its stored displacement equals the donor state. If this makes the next generated token match the donor, the shared-prefix condition can continue at the following step. Placing the intervention after the final attention operation helps: the edit does not directly alter future attention keys or values. Generated token identities still affect subsequent computation. Floating-point differences between teacher-forced and cached execution can also matter, which is why free-generation validation is required rather than relying on this argument alone.

### What is persisted

The safetensors file contains keys, adjustments, sequence trajectories, slot controls, and compatibility metadata. It does not contain per-entry question strings, answer strings, donor prompts, or token IDs. A fixed system prompt is part of the metadata. The separate question catalogue and diagnostic reports are authoring and evaluation resources; ordinary question inference does not use them as an answer database.

![Position-indexed numerical replay](figures/illustration-03.png)

*Illustration 3. Inference schematic. Routing occurs once per answer, while the selected adjustment varies with decoding position. This is restricted activation replay, not a stored answer-string lookup.*

## Development evaluation

The source catalogue was imported from the workbook\
`chatbot-1000-questions-and-answers.xlsx`. It contains 1,000 questions in 25 categories, with 40 questions per category. It is a curated question bank, not a measured frequency ranking. Importing all entries does not establish successful writing of all entries.

The sequence pilot used 12 selected questions across 12 categories. Each successful write was checked by generating from its original question. Matching collapsed whitespace and ignored case; punctuation and substantive wording still had to agree. The donor instruction was refined using development cases, so this is not a held-out evaluation.

|  ID | Source question                  | Steps | Time (s) |
|----:|:---------------------------------|------:|---------:|
|   7 | What is a system prompt?         |    21 |    0.912 |
|  41 | How do I start an essay?         |    25 |    1.007 |
|  81 | What is a noun?                  |    27 |    1.077 |
| 121 | How do I study more effectively? |    26 |    1.036 |
| 161 | How do I calculate a percentage? |    34 |    1.355 |
| 201 | Why is the sky blue?             |    22 |    0.899 |
| 241 | What was the Renaissance?        |    28 |    1.145 |
| 281 | What are the seven continents?   |    32 |    1.265 |
| 321 | What is an operating system?     |    20 |    1.003 |
| 361 | What is Python?                  |    21 |    0.850 |
| 401 | What is HTML?                    |    25 |    0.995 |
| 441 | What is a spreadsheet formula?   |    23 |    0.916 |

Table 1. All 12 writes passed normalized full-answer matching at write time. Steps include the stop token; times cover steered generation, excluding loading and the full writing procedure.

The 12 trajectories contain 304 steps. Recorded generation times range from 0.850 to 1.355 seconds, with a median of approximately 1.005 seconds. These are local observations, not a controlled throughput benchmark. Entries were written into a growing memory, but the experiment did not exhaustively retest every previous entry after every later write.

### Replacement, isolation, and restoration

A replacement trial rewrote the Python answer to: *In this fictional setting, Python is a floating library above the clouds.* The new 17-step trajectory reproduced that sentence, including after saving and reloading. This demonstrates user-directed replacement rather than an assertion about Python.

Five other questions—about boiling water, writing a good prompt, black cats, Python exceptions, and watersheds—selected no slot and produced the same answers as the baseline. Clearing all memory restored the baseline response to the Python question. These controls test preservation of baseline behavior, not factual accuracy; five examples do not establish a general false-activation rate.

With blank memory, the smoke test recorded a maximum logit difference of zero. SHA-256 hashes over the base model’s named parameters also matched before and after validation. Six unit tests covered blank behavior, routing, equivalence of the two-hook intervention to the explicit equation, persistence checks, replacement and clearing, and sequence persistence.

### Recognition limits

An earlier two-entry sequence test used the paraphrase *Explain what a system prompt does.* Its score was approximately 0.9792, below the 0.999 threshold, so memory did not activate. A strict threshold helps avoid unrelated matches but can miss semantically similar wording. This pilot did not evaluate the remaining 988 catalogue entries, broad paraphrase coverage, multi-turn histories, or adversarial near-matches.

![Recognition and reproduction are different tests](figures/illustration-04.png)

*Illustration 4. Reported recognition example. The strict default threshold rejects one tested paraphrase despite successful exact-source sequence writes; these are development observations.*

## Costs and limitations

For width $d=1024$, $S=1000$ slots, and float32 storage, the fixed matrices require
$$

2Sd(4\ \text{bytes})=8{,}192{,}000\ \text{bytes}=7.8125\ \text{MiB}.

$$
Each sequence step adds 4 KiB. The 304-step pilot adds 1.1875 MiB; 1,000 answers averaging 30 steps would add approximately 117.19 MiB, beyond the fixed matrices and controls. The first adjustment is also retained in $D$. This is larger than storing the answer text; no storage-compression advantage is claimed.

Recognition costs $O(Sd)$ per question and applying a selected adjustment costs $O(d)$ per token. Writing requires donor generation, two teacher-forced traces, consistency checks, baseline generation, and free-generation validation. Keys and single adjustments are non-trainable parameters; sequence trajectories are buffers. Both are separately persisted numerical memory, not modified base parameters.

Exact-source reproduction does not establish general reasoning, factuality, paraphrase recognition, or general reconstruction of earlier questions. Next experiments should use held-out questions, matched donor prompts for single/sequence comparisons, retention tests after all writes, and threshold/gain sweeps with hard negatives. Low-rank trajectory storage is a possible extension, not a demonstrated result.

## Related work: comparison with MEMORILLA

MEMORILLA [4](#ref-memorilla) shares the goal of supplying a frozen LLM with additional latent information. Its frozen encoder stores document embeddings; a trained memory module reads the collection conditioned on a query and produces soft tokens in the LLM’s input embedding space. Its supervised experiments use 16 memory tokens with Qwen3-8B. Adding a document requires encoding it, not retraining the LLM.

LAMP-Qwen instead writes normalized keys and source–donor activation differences without training a memory module. It selects one eligible slot and edits the final pre-FFN residual state, rather than adding input tokens. Its sequence storage grows with answer length. MEMORILLA’s fixed token budget limits decoder context, not the size of its growing embedding store. MEMORILLA addresses document-based recall and composition; LAMP-Qwen currently demonstrates explicit exact-source answer programming. Their evaluations differ substantially: MEMORILLA reports eight benchmarks and an agent setting, whereas this report presents a 12-question development pilot. No comparative accuracy, latency, or novelty claim follows from these results.

Fast-weight programming [5](#ref-fastweights) also studies writable numerical state, while knowledge editors can learn targeted parameter updates [6](#ref-editing). LAMP-Qwen’s narrower contribution is an inspectable forward-only activation intervention with a frozen checkpoint. The LAMP code is MIT licensed; upstream model and dependency licenses remain separate.

![Separate storage enables reversible edits](figures/illustration-05.png)

*Illustration 5. Storage and reversibility schematic. Numerical memory is persisted separately from the frozen model. Its reversibility does not make encoded associations confidential.*

## Practical utility, reversibility, and recoverability

### Uses and comparison with output controls

The immediate practical uses are controlled answer overrides, swappable sets of associations, and educational experiments in which users inspect, replace, or disable numerical memories while retaining the same base model. Local personalization is plausible for selected associations, but automatic learning, conversational recall, and broad domain expertise have not been demonstrated. A useful next evaluation would compare LAMP with prompt instructions, retrieval, and answer replacement on identical edits, measuring exact answers, unseen paraphrases, related reasoning, unrelated questions, latency, and storage.

An output filter can replace a completed answer string; LAMP instead changes hidden states before token selection. Prompt instructions and constrained decoding provide other ways to control generation. All can yield the same visible answer, and semantic recognition is not unique to LAMP. For fixed question–answer replacement, a conventional lookup is simpler and may be more reliable. Sequence memory remains a model-dependent trajectory for a selected answer, not evidence of a general knowledge update. Its value beyond replacement depends on demonstrating useful generalization. Reusable steering of tone or explanation style is a possible extension, motivated by activation-engineering research [7](#ref-actadd), rather than an established capability of this writer.

### Reversible edits and deployment visibility

Memory-file replacement, slot disabling, and clearing make interventions reversible without restoring a modified base checkpoint. Reversibility here means restoring the base computation, not guaranteeing that its answers are correct. Sharing a memory requires compatible model, runtime, and prompting settings. Removing the writer alone preserves inference; removing the inference hooks disables the intervention. The present implementation uses additional tensors and hooks, not another transformer block. File or execution inspection can expose those additions, whereas an answer-only API does not reveal the selected slot or its score. API probing can reveal effects without establishing their internal cause.

### Recovering an association from an exported memory

Numerical storage is not encryption. In a subsequent exploratory test, an exported memory’s slot 6 contained a seven-step trajectory. Twenty questions were tried with that slot forcibly activated in an in-memory copy; the output for a Texas-capital question suggested *Fayetteville*. Fifty state-capital questions were then compared with the stored recognition key. *What is the capital of Arkansas?* obtained a cosine score reported as 1.000000. With the original slot controls restored, that question selected slot 6 normally and produced *Fayetteville.* The memory’s owner confirmed both the source question and the programmed answer. The supplied file was not modified.

This is one candidate-based recovery, not a blind inversion benchmark or proof that arbitrary questions are recoverable. The preliminary outputs guided the candidate family; a reported score of one alone would not prove unique recovery. The programmed answer was an intentional counterfactual. The result nevertheless shows that omitting per-entry text does not ensure confidentiality. The key, adjustment sequence, model, and runtime together can support probing. Embedding-inversion results [8](#ref-inversion) reinforce the need for testing, but their recovery rates cannot be transferred to these Qwen states. Exact wording, approximate meaning, and answer recovery should be evaluated separately; no recovery-time or success-rate estimate is established for unconstrained questions.

### Scaling limits

A million entries averaging 50 generation steps would occupy about 198.4 GiB in fixed and sequence tensors, excluding controls, the base model, and working space. The present implementation holds these tensors in RAM, scans all keys, and copies large arrays during writing. Indexed recognition and disk-backed trajectories could reduce RAM demand, but are unimplemented and would require latency and false-match evaluation. Neither storage efficiency nor reliable million-entry operation has been demonstrated.

## AI-use disclosure

This project was created with assistance from GPT-6 Astra and Codex. AI tools supported software development, technical exploration, and drafting and revision of the report. William Taggart is responsible for the research decisions and final software and documentation. AI assistance does not constitute independent validation of the implementation or its scientific claims.

## References

<a id="ref-lamp"></a>

1. William Taggart. 2026. *LAMP: Latent Associative Memory Programming*. Software. [https://github.com/FL2744/LAMP](https://github.com/FL2744/LAMP).

<a id="ref-qwen"></a>

2. Qwen Team. 2026. *Qwen3.5-0.8B: Model and configuration*. Model and configuration. [https://huggingface.co/Qwen/Qwen3.5-0.8B](https://huggingface.co/Qwen/Qwen3.5-0.8B).

<a id="ref-ollama"></a>

3. Ollama. 2026. *Chat API documentation*. Accessed November 2026. [https://docs.ollama.com/api/chat](https://docs.ollama.com/api/chat).

<a id="ref-memorilla"></a>

4. A. Fallahpour and others. 2026. *Memorilla: Latent Semantic Memory for LLMs*. arXiv:2610.21375v3; project: https://memory.stanford.edu/. [https://arxiv.org/abs/2610.21375v3](https://arxiv.org/abs/2610.21375v3).

<a id="ref-fastweights"></a>

5. I. Schlag and K. Irie and J. Schmidhuber. 2021. *Linear Transformers Are Secretly Fast Weight Programmers*. ICML. [https://arxiv.org/abs/2102.11174](https://arxiv.org/abs/2102.11174).

<a id="ref-editing"></a>

6. N. De Cao and W. Aziz and I. Titov. 2021. *Editing Factual Knowledge in Language Models*. EMNLP. [https://aclanthology.org/2021.emnlp-main.522/](https://aclanthology.org/2021.emnlp-main.522/).

<a id="ref-actadd"></a>

7. A. M. Turner and others. 2024. *Steering Language Models With Activation Engineering*. arXiv:2308.10248v5. [https://arxiv.org/abs/2308.10248v5](https://arxiv.org/abs/2308.10248v5).

<a id="ref-inversion"></a>

8. J. Morris and V. Kuleshov and V. Shmatikov and A. Rush. 2023. *Text Embeddings Reveal (Almost) As Much As Text*. EMNLP. [https://aclanthology.org/2023.emnlp-main.765/](https://aclanthology.org/2023.emnlp-main.765/).

## Suggested citation

William Taggart. 2026. LAMP-Qwen: Forward-Only Associative Memory for a Frozen Small Language Model. Technical report. Modern and Classical Languages and Literatures, Virginia Tech. November 13, 2026. https://huggingface.co/will-taggart/LAMP-Qwen-v0.1
